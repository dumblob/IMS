/**
 * Topic:   Okruh 4: SHO Vyrobni linka
 *          Vyroba reklam BOSE
 * Authors: Jan Pacner (xpacne00@stud.fit.vutbr.cz)
 *          Lukas Frencl (xfrenc00@stud.fit.vutbr.cz)
 * Date:    2012-12-01 10:56:23 CET
 */

#include <simlib.h>
#include <iostream>
#include <fstream>
//using namespace std;

double L = 0.1;
const double X = 3.1415926535;

int main()
{
  std::ifstream f("nazev_souboru.txt");
  if (!f) { std::cerr << "fail" << std::endl; return 1; }

  //t

  std::cout << "Hello" << std::endl;
  return 1;
}
